-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: yoga
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq` (
  `no` int NOT NULL AUTO_INCREMENT,
  `writer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `content` varchar(3000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `regtime` varchar(100) COLLATE utf8mb4_0900_as_cs NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'운영자','요가는 무슨 뜻인가요?','저희 요가는 \'요즘 우리가 가는곳\'의 줄임말로, 온라인 화상 서비스로 다양한 사람들과 취향을 만족시켜줄 온라인 미팅 포차를 뜻합니다.','2021-02-04 08:58'),(2,'운영자','fnq관리게시판, 무엇이 좋은가요?','fnq관리는 운영진이 게시판에서 등록 및 관리할 수 있습니다. 최근 게시물은 회원들이 쉽게 확인할 수 있습니다.','2021-02-07 12:53'),(3,'운영자','방만들기 문의','방은 메인 게시판 오른쪽 상단에 있는 캠코더 이미지를 클릭하셔서 만드실 수 있습니다. 만들 당시 방 테마, 소개, 이름을 설정하실 수 있으시며 원하시는 사진을 썸네일로 지정하실 수 있습니다.','2021-02-08 16:27'),(4,'운영자','비밀번호를 수정할 수 있나요?','회원정보 수정은 오른쪽 상단에 navbar에서 회원정보를 클릭하시면 비밀번호를 수정하실 수 있습니다.','2021-02-10 08:30'),(5,'운영자','원하는 방을 찾고싶어요','특정 방을 찾으신다면 메인화면 왼쪽 하단에 필터를 이용하시거나 상단에 있는 검색창을 이용하시면 수월하게 원하는 방을 찾으실 수 있습니다.','2021-02-11 14:54'),(6,'운영자','비밀번호를 까먹을 시 어떻게 찾을 수 있나요?','비밀번호를 잊으셨다면 로그인 창 회원가입 밑에 비밀번호 찾기 기능을 통해 회원가입 시 등록하신 이메일로 임시 비밀번호를 받으실 수 있습니다','2021-02-11 16:59'),(7,'운영자','방에서 게임을 어떻게 시작하나요?','해당 방에서 오른쪽 하단 조이스틱 그림을 클릭하시면 원하시는 게임을 실행하실 수 있습니다.','2021-02-12 09:27'),(8,'운영자','방에서 제 마이크를 끄고싶어요','방에 입장하셨을 경우, 채팅창(채팅창이 없는경우 오른쪽 상단 채팅 이미지를 클릭)하단에서 스피커x 모양을 누르시면 음소거가 됩니다. ','2021-02-12 21:17'),(9,'운영자','방에서 제 카메라 영상을 끄고싶어요','방에 입장하셨을 경우, 채팅창(채팅창이 없는경우 오른쪽 상단 채팅 이미지를 클릭)하단에서 카메라x 모양을 누르시면 카메라가 정지됩니다. ','2021-02-14 23:18'),(10,'운영자','유저에게 귓속말을 하고싶어요','방에 입장하셨을 경우, 채팅창(채팅창이 없는경우 오른쪽 상단 채팅 이미지를 클릭)하단에 모두 오른쪽을 클릭하면 방에있는 유저들이 나오는데, 귓속말을 보내고 싶은 유저를 클릭하신 후 채팅을 하시면 됩니다.','2021-02-15 19:47'),(11,'운영자','방을 나가고 싶어요','방에 입장하셨을 경우, 채팅창(채팅창이 없는경우 오른쪽 상단 채팅 이미지를 클릭)하단에서 가장 오른쪽 문 모양을 누르시면 해당 방에서 퇴장됩니다. ','2021-02-15 15:09');
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-19 15:51:11
