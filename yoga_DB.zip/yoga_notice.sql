-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: yoga
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `no` int NOT NULL AUTO_INCREMENT,
  `writer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `content` varchar(3000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `regtime` varchar(100) COLLATE utf8mb4_0900_as_cs NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'운영자','요가에 오신 여러분을 환영합니다 ','요가에 오신 여러분을 환영합니다!\r  \r                 온라인 화상 서비스로 다양한 사람들과 취향을 만족시켜줄 온라인 미팅 서비스를 제공합니다.\r \r                 요가에서는 여러가지 다양한 룸을 통해 마음이 맞는 사람들과 음악과 함께 이야기를 나누실 수 있으며 더불어 함께 여러가지 게임도 즐기실 수 있습니다\r \r                 저희 요가에 오신 여러분께 진심으로 감사드리며 좋은 인연도 만나시길 바라겠습니다 :D','2021-02-04 09:13'),(2,'운영자','요가 규정','모든 회원님들은 가입과 동시에 \'요가 공통 규정\'에 따라주셔야 하며 그렇지 않을 경우 탈퇴 등의 처리가 될 수 있습니다.','2021-02-05 10:11'),(3,'운영자','요가 공통규정1',' 욕설, 비속어, 공격적인 말투, 비꼬기 및 심한 언행은 그 어떤 경우에도 허용되지 않습니다.','2021-02-07 01:15'),(4,'운영자','요가 공통규정2',' 종교/ 정치/ 인종/ 성/ 지역 등의 문제가 발생할 수 있는 주제에 대해서 작성을 금지합니다.','2021-02-07 13:27'),(5,'운영자','요가 공통규정3','3. 회원간에 채팅을 이용하여 공격하는 모든 행위는 허용되지 않습니다.','2021-02-09 15:39'),(6,'운영자','요가의 뜻','저희 요가는 \'요즘 우리가 가는곳\'의 줄임말로, 온라인 화상 서비스로 다양한 사람들과 취향을 만족시켜줄 온라인 미팅 서비스를 제공합니다.','2021-02-11 10:31'),(7,'운영자','회원 가입 ','저희 요가에서는 회원가입을 하기위해선 카카오톡 연동을 권장합니다. 카카오톡 프로필사진과 자기소개 문구로 자신을 멋지게 소개해주세요!','2021-02-12 01:01'),(8,'운영자','이용 시 녹화 금지','저희 요가를 이용 시 녹화는 어떠한 사유로도 금지됩니다. ','2021-02-14 18:31'),(9,'운영자','저작권 관련 공지','요가를 이용 시 화면공유를 통해 저작권에 위반되는 행위나 유포는 금물합니다.','2021-02-15 09:29'),(10,'운영자','공지사항 등록 ','공지사항 등록에는 운영자 외에는 작성하실 수 없습니다.','2021-02-16 13:27'),(11,'운영자','피드백','요가에 있어 피드백 의견은 fnq에 언제든 물어봐주세요','2021-02-17 17:21');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-19 15:51:02
