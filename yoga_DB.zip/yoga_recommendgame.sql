-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: yoga
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recommendgame`
--

DROP TABLE IF EXISTS `recommendgame`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendgame` (
  `id` int NOT NULL AUTO_INCREMENT,
  `game` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendgame`
--

LOCK TABLES `recommendgame` WRITE;
/*!40000 ALTER TABLE `recommendgame` DISABLE KEYS */;
INSERT INTO `recommendgame` VALUES (1,'화면공유 기능을 활용해서 캐치마인드 게임을 해보세요. (설명 : 화면공유를 하는 사람이 생각나는 단어를 그림판에 그려 그 단어를 맞추는 게임 )'),(2,'개인 채팅을 통해 귓속말 게임을 해보세요. (설명 : 개인 채팅으로 물어보고 싶은 상대에서 질문하고 질문받은 사람이 모두에게 대답을 하는 게임. 질문이 궁금하면 방장이 시키는 대로)'),(3,'음소거 기능과 화면 중지 기능을 활용하여 고요 속에 외침을 해보세요. (설명 : 두 사람이 하는 게임으로 한 사람은 음소거를 하고 제시어를 동작 없이 설명하고 다른 한 사람이 그  제시어를 맞추는 게임)'),(4,'화면공유 기능과 유튜브 사이트를 활용해서 드라마 OST 맞추기 게임을 해보세요. (설명 : 화면공유 기능으로 유튜브에 접속해 다 같이 드라마 OST 맞추는 게임) '),(5,'화면공유 기능과 음악 사이트를 활용해서 \"놀라운 토요일\"을 해보세요.  (설명 : 화면공유 기능으로 유튜브에 접속해 다 같이 노래의 한 소절 가사 받아쓰기하는 게임) '),(6,'화면공유 기능과 네이버 사다리 타기를 통해서 게임을 해보세요.'),(7,'이미지 게임!!! (손병호 게임!!!)'),(8,'레코드 게임!!! ( 설명 : 한 사람이 제시어를 말하면 다른 사람들이 각자 그 제시어에 관한 노래 한 소절을 부르는 게임)'),(9,'지금 게임 추천 누른 사람이 무반주로 노래 한 소절~~!!'),(10,'지금 게임 추천 누른 사람이 여기서 가장 마음에 드는 사람 전체 채팅에으로 이름 치기!!!!');
/*!40000 ALTER TABLE `recommendgame` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-19 15:51:05
