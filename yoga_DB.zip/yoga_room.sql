-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: yoga
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `session_id` int NOT NULL AUTO_INCREMENT,
  `owner_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `theme` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `introduce` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `thumbnail` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `maleNum` int NOT NULL,
  `femaleNum` int NOT NULL,
  `rate` int NOT NULL,
  `token` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `maxNum` int DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (330,'SAMPLE','샘플방-하정우급 먹방','밥먹자','같이 먹을사람','있음',3,3,2,NULL,0),(331,'SAMPLE','샘플방-햇님이랑 같이 술드실분?','술방','샘플방-햇님이랑 같이 술드실분?','있음',2,2,2,NULL,0),(333,'SAMPLE','샘플방-페이커가 왼손으로 이겨준대요','기타','샘플방-페이커가 왼손으로 이겨준대요','있음',1,4,2,NULL,0),(334,'SAMPLE','샘플방-조과장님과 함꼐하는 신나는 회식^^','회식','ㅎㅇ','있음',2,3,2,NULL,0),(335,'SAMPLE','샘플방-2시간동안 심도깊은 토론하실분들만 받습니다.','응답하라','샘플방-2시간동안 심도깊은 토론하실분들만 받습니다.','있음',3,1,2,NULL,0),(336,'SAMPLE','샘플방-드루와드루와','술방','샘플방-드루와드루와','있음',0,6,2,NULL,0),(337,'SAMPLE','샘플방-응답하라 8090!!!!다 들어와요!!!','응답하라','샘플방-응답하라 8090!!!!다 들어와요!!!','있음',4,2,2,NULL,0),(338,'SAMPLE','샘플방-인천여고 얼짱출신','남여','ㅎㅇ','있음',3,1,2,NULL,0),(339,'SAMPLE','샘플방-이왜진??유재석이 요가에서 라면을 먹고 있다고???','밥먹자','샘플방-이왜진??유재석이 요가에서 라면을 먹고 있다고???','있음',1,4,2,NULL,0),(340,'SAMPLE','샘플방-호구마!!!!!!!','EDM','샘플방-호구마!!!!!!!','있음',5,0,2,NULL,0),(341,'SAMPLE','샘플방-짝남한테 차인 썰 푼다 들어와라','술방','ㅎㅇ','있음',2,3,2,NULL,0),(343,'SAMPLE','샘플방-고독','회식','샘플방-고독','있음',1,2,2,NULL,0),(344,'SAMPLE','샘플방-다들 직급 달고 오세요. 사장은 나 하나임!','회식','샘플방-다들 직급 달고 오세요. 사장은 나 하나임!','있음',6,0,2,NULL,0),(345,'SAMPLE','샘플방-빠꾸없이 달릴 사람들~~~~','술방','ㅇㅁㄴㅇ','있음',2,3,2,NULL,0),(346,'SAMPLE','샘플방-수컷의향기를 소개합니다.','남여','수컷','있음',1,2,2,NULL,0),(347,'SAMPLE','샘플방-성수 씨잼 랩하우스','힙합','ㅇㅁㄴ','있음',2,1,2,NULL,0),(348,'SAMPLE','샘플방-재벌의 삶 궁금하세요?','남여','재벌','있음',3,4,2,NULL,0),(349,'SAMPLE','샘플방-LIT!!!!!','힙합','샘플방-LIT!!!!!','있음',4,3,2,NULL,0),(350,'SAMPLE','샘플방-역삼 머쉬베놈이다 들와라','힙합','ㅎㅇ','있음',5,0,2,NULL,0),(351,'SAMPLE','샘플방-왜 이렇게 늦게왔어...','남여','샘플방-왜 이렇게 늦게왔어..','있음',2,2,2,NULL,0),(352,'SAMPLE','샘플방-하루에 소개팅 2번??!!','남여','샘플방-하루에 소개팅 2번??!!','있음',1,1,1,NULL,0),(353,'SAMPLE','샘플방-반갑다!! 7080','응답하라','ㅇㄴㅁ','있음',0,4,2,NULL,0),(354,'SAMPLE','샘플방-와 EDM을 뒤집어 놓으셔따.','EDM','샘플방-와 EDM을 뒤집어 놓으셔따.','있음',3,5,2,NULL,0),(355,'SAMPLE','샘플방-랜선 데이트 할 여자 들어와 (20남)','남여','ㅇㅁㄴㅇㅁㄴ','있음',0,2,2,NULL,0),(356,'SAMPLE','샘플방-EDM 감성 궁금해? ','EDM','EDM','있음',0,3,2,NULL,0),(357,'SAMPLE','샘플방-알록달록 스키니진 감성 아는사람만','응답하라','샤이니isback','있음',2,4,2,NULL,0),(358,'SAMPLE','샘플방- 소리 벗고 팬티 질러~~!~!!!~!~!!','EDM','ㅇㅁㄴㅇㅁㄴㅇㅁㄴ','있음',1,5,2,NULL,0),(359,'SAMPLE','샘플방-랩 배틀 덤빌 사람 2명 구함','힙합','샘플방-랩 배틀 덤빌 사람 22명 구함','있음',2,3,2,NULL,0),(360,'SAMPLE','샘플방-요즘 누가 힙합 들음? EDM ㄱㄱ','EDM','샘플방-요즘 누가 힙합 들음? EDM ㄱㄱ','있음',3,2,2,NULL,0),(361,'SAMPLE','샘플방-고로상의 텐동먹방','밥먹자','ㄱㄽ','있음',6,1,2,NULL,0),(362,'SAMPLE','샘플방-퇴근하고 다 같이 시원한 맥주 ','회식','ㅇㅁㄴㅇ','있음',4,0,2,NULL,0),(363,'SAMPLE','샘플방-아스날 팬..','기타','샘플방-아스날 팬..','있음',1,3,2,NULL,0),(364,'SAMPLE','흥 책임져','남여','소스소스소스소스소스소스소스소스소스소스소스소스','있음',4,4,2,NULL,0),(365,'SAMPLE','샘플방-SON 같이 볼래??','기타','샘플방-SON 같이 볼래??','있음',2,5,2,NULL,0),(366,'SAMPLE','샘플방-밥 갖고 와!!!','밥먹자','샘플방-밥 갖고 와!!!','있음',3,0,2,NULL,0);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-19 15:51:24
